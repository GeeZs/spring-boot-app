create function time(abstime) returns time without time zone
STABLE
LANGUAGE SQL
AS $$
select cast(cast($1 as timestamp without time zone) as pg_catalog.time)
$$;
